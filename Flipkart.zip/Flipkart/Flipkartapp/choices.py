RATING_CHOICES = (
    (1, "VERY_POOR"),
    (2, "POOR"),
    (3, "SATISFIED"),
    (4, "VERY_GOOD"),
    (5, "EXCELLENT")
)
