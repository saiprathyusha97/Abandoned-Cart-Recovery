from django.views.generic import DetailView, CreateView, UpdateView, DeleteView, ListView
from Flipkartapp.models import *
from django.shortcuts import *
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
import smtplib


class cartlistview(LoginRequiredMixin, ListView):
    login_url = '/login/'
    model = addtocart
    context_object_name = 'object'
    template_name = "addtocartinfo.html"

    def get_queryset(self):
        user = self.request.user
        return addtocart.objects.filter(user=user)

    def get_context_data(self, **kwargs):
        context = super(cartlistview, self).get_context_data(**kwargs)
        context.update({'user_permissions': self.request.user.get_all_permissions()})
        userinfoid = userinfo.objects.get(user=self.request.user)
        context.update({'obj': userinfoid.id})
        return context


# def sendEmail(request) :
#     user = request.user
#     s = smtplib.SMTP('smtp.gmail.com', 587)
#     s.starttls()
#     s.login("flipkart.wannacode@gmail.com", "prathyukrishna")
#     #message = "Hello Welcome to Flipkat!!"
#
#     SUBJECT = "Welcome to Flipkart!!"
#
#     TEXT = "Hello Welcome to a platform which satisfies all the needs from anywhere and at anyplace -------- Flipkart!!"
#     message = 'Subject: {}\n\n{}'.format(SUBJECT, TEXT)
#     s.sendmail("flipkart.wannacode@gmail.com", user.email, message)
#     s.quit()


def addnewitem(request, pk):
    if request.user.is_authenticated:
        user = request.user
        item = Item.objects.get(id=pk)
        itemtocart = addtocart(user=user, item=item, price=item.price, image=item.image, quantity=1)
        itemtocart.save()
        #sendEmail(request)
        return redirect('Flipkartapp:cartitems')
    else:
        return redirect('Flipkartapp:login')





def addexistitem(request, pk):
    if request.user.is_authenticated:
        user = request.user
        cart = addtocart.objects.get(id=pk)
        cart.quantity = cart.quantity + 1
        item = Item.objects.get(id=cart.item.id)
        cart.price = cart.price + item.price
        cart.save()
        return redirect('Flipkartapp:cartitems')
    else:
        return redirect('Flipkartapp:login')


def addexisttoabandonedcart(request, pk):
    if request.user.is_authenticated:
        user = request.user
        cart = addtocart.objects.get(id=pk)
        item = Item.objects.get(id=cart.item_id)
        ac = addtoabandonedcart(user=user, item=item, price=item.price, image=item.image)
        ac.save()
        cart.delete()
        return redirect('Flipkartapp:cartitems')
    else:
        return redirect('Flipkartapp:login')



class Deleteitem(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = addtocart
    template_name = 'deleteform.html'
    success_url = reverse_lazy('Flipkartapp:cartitems')

    def has_permission(self):
        pk = self.kwargs['pk']
        user_id = self.request.user.id
        # import ipdb
        # ipdb.set_trace()
        check_user = addtocart.objects.get(pk=pk).user.id

        if not user_id == check_user:
            self.raise_exception = True
            success_url = reverse_lazy('Flipkartapp:cartitems')
            return False
        else:
            def get(self, request, *args, **kwargs):
                return self.post(request, args, kwargs)

            success_url = reverse_lazy('Flipkartapp:cartitems')
            return True


def cashondelivercart(request):

    return render(request, 'payment_successcart_cash.html')


def Bookitem(request):
    queryset = addtocart.objects.all()
    user = request.user
    for iter in queryset:
        if iter.user == user:
            bookobj = Bookedinfo(user=user, item=iter.item, price=iter.price, image=iter.image, quantity=1)
            bookobj.save()
    return redirect("Flipkartapp:Bookeditems")
