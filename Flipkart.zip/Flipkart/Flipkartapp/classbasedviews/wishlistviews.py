from django.views.generic import DetailView, CreateView, UpdateView, DeleteView, ListView
from Flipkartapp.models import *
from django.shortcuts import *
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
import smtplib

class wishlistview(LoginRequiredMixin, ListView):
    login_url = '/login/'
    model = wishlist
    context_object_name = 'object'
    template_name = "wishlistinfo.html"

    def get_queryset(self):
        user = self.request.user
        return wishlist.objects.filter(user=user)

    def get_context_data(self, **kwargs):
        context = super(wishlistview, self).get_context_data(**kwargs)
        context.update({'user_permissions': self.request.user.get_all_permissions()})
        return context


def sendEmail(request) :
    user = request.user
    s = smtplib.SMTP('smtp.gmail.com', 587)
    s.starttls()
    s.login("flipkart.wannacode@gmail.com", "prathyukrishna")
    #message = "Hello Welcome to Flipkat!!"

    SUBJECT = "Welcome to Flipkart!!"

    TEXT = "Hello Welcome to a platform which satisfies all the needs from anywhere and at anyplace -------- Flipkart!!"
    message = 'Subject: {}\n\n{}'.format(SUBJECT, TEXT)
    s.sendmail("flipkart.wannacode@gmail.com", user.email, message)
    s.quit()


def addnewwishitem(request, pk):
    if request.user.is_authenticated:
        user = request.user
        item = Item.objects.get(id=pk)
        itemtocart = wishlist(user=user, item=item, price=item.price, image=item.image)
        itemtocart.save()
        sendEmail(request)
        return redirect('Flipkartapp:items')
    else:
        return redirect('Flipkartapp:login')


class Deletewishlistitem(LoginRequiredMixin, PermissionRequiredMixin,DeleteView):
    model = wishlist
    template_name = 'deleteform.html'
    success_url = reverse_lazy('Flipkartapp:wishlistitems')

    def has_permission(self):
        pk = self.kwargs['pk']
        user_id = self.request.user.id
        # import ipdb
        # ipdb.set_trace()
        check_user = wishlist.objects.get(pk=pk).user.id

        if not user_id == check_user:
            self.raise_exception = True
            success_url = reverse_lazy('Flipkartapp:wishlistitems')
            return False
        else:
            def get(self, request, *args, **kwargs):
                return self.post(request, args, kwargs)

            success_url = reverse_lazy('Flipkartapp:wishlistitems')
            return True
