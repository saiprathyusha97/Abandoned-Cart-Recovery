from django.apps import AppConfig


class FlipkartappConfig(AppConfig):
    name = 'Flipkartapp'
